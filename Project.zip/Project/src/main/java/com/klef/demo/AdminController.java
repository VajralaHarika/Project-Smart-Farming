package com.klef.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {
	 @Autowired
	 private AdminRepository adminRepo;
	  /*   
	 @GetMapping("/admindashboard")
		public ModelAndView admindashboard()
		{
			ModelAndView mv =new ModelAndView();
			mv.setViewName("admindashboard");
			
			return mv;
		}
	 */
	 
	 @GetMapping("/adminlogin")
		public ModelAndView admin()
		{
			ModelAndView mv =new ModelAndView();
			mv.setViewName("adminlogin");
			
			return mv;
		}
	 @GetMapping("/admindashboard")
		public ModelAndView admindashboard()
		{
			ModelAndView mv =new ModelAndView();
			mv.setViewName("admindashboard");
			
			return mv;
		}
	 
	 /*
	 @GetMapping("/adminregister")
	 public ModelAndView addadmin() {
		 return new ModelAndView("adminsignup","admin",new Admin());
	 }
	 
	 
	 @PostMapping("/submitadmin")
	 public ModelAndView processRegister(@ModelAttribute("admin") Admin admin) {
		 ModelAndView mv = new ModelAndView();
	     BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	     String encodedPassword = passwordEncoder.encode(admin.getPassword());
	     admin.setPassword(encodedPassword);  
	     adminRepo.save(admin);
	     mv.setViewName("asignupsuccess");
	     mv.addObject("username",admin.getUsername());
	     return mv;
	 }
	 
	
	@GetMapping("/checkadmin")
	@ResponseBody()
	public String auth1(@RequestParam("uname") String username,@RequestParam("pwd") String password)
	{
		if(username.equals("admin") && password.equals("farmfresh"))
		{
			return "redirect:/admindashboard";
		}
			
		else
		{
			return "redirect:/adminlogin";
		}
	}
	 */
	 
	 
	 @PostMapping("/checkadmin")
	 public ModelAndView admincheck(@RequestParam("username") String username,@RequestParam("password") String password)
	 {
		 ModelAndView mv=new ModelAndView();
		 System.out.println(username+" "+password);
		 if(username.equals("admin") && password.equals("farmfresh"))
		 {
			 mv.setViewName("admindashboard");
			 return mv;
		 }
		 else
		 {
			 mv.setViewName("adminlogin");
			 return mv;
		 }
	 }
	
	
}
