package com.klef.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
	 @Autowired
	 private UserRepository userRepo;
	     
	 @GetMapping("")
	 public ModelAndView index()
	 {
		ModelAndView mv =new ModelAndView();
		mv.setViewName("index");
		return mv;
	 }
	 
	 @GetMapping("/home")
	public ModelAndView home()
	{
		ModelAndView mv =new ModelAndView();
		mv.setViewName("home");
		
		return mv;
	}
	 
	 @GetMapping("/shop")
		public ModelAndView products()
		{
			ModelAndView mv =new ModelAndView();
			mv.setViewName("products");
			
			return mv;
		}
	
	 @GetMapping("/newhome")
		public ModelAndView newhome()
		{
			ModelAndView mv =new ModelAndView();
			mv.setViewName("newhome");
			
			return mv;
		}
	 
	 
	 @GetMapping("/register")
	 public ModelAndView adduser() {
		 return new ModelAndView("signup","user",new User());
	 }
	 
	 @PostMapping("/submituser")
	 public ModelAndView processRegister(@ModelAttribute("user") User user) {
		 ModelAndView mv = new ModelAndView();
	     BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	     String encodedPassword = passwordEncoder.encode(user.getPassword());
	     user.setPassword(encodedPassword);  
	     userRepo.save(user);
	     mv.setViewName("signupsuccess");
	     mv.addObject("username",user.getName());
	     return mv;
	 }
	 
	 @GetMapping("/admin/viewallusers")
		public ModelAndView viewallusers()
		{
			List<User> users = userRepo.findAll();
			ModelAndView mv = new ModelAndView();
			mv.setViewName("viewallusers");
			mv.addObject("userdata",users);
			return mv;
		}
	 
	
	
	
		
}
